package numeros;

import java.io.File; // Manejo de archivos.
import java.io.FileNotFoundException; // Excepciones al manejar archivos.
import java.io.IOException; // Manejo de excepciones relacionadas con operaciones I/O.
import java.io.RandomAccessFile; // Manejo y manipulación de archivos de forma aleatoria.
import java.nio.channels.FileChannel; // Manejo y manipulación de archivos.
import java.nio.channels.FileLock; // Bloqueo de archivos o regiones de archivos.
import java.nio.channels.OverlappingFileLockException; // Tratamiento de excepciones
import java.util.Random; // Generación de números aleatorios.
import java.util.Scanner; // Entrada de datos por teclado. 
import java.util.logging.Level; // Niveles de registro utilizados para controlar grabación de registros.
import java.util.logging.Logger; // Registrar mensajes para un sistema o componente de la aplicación.

/**
 * @author Sandra
 * Esta aplicación tiene como finalidad escribir 10 números
 * aleatorios en un archivo, dentro de un mismo proceso.
 * La aplicación se asegura que, aunque sea ejecutada por múltiples
 * procesos simultáneamente, los datos se escribián de forma
 * segura utilizando bloqueos de archivo.
 * Implementa el control de acceso concurrente a un recurso
 * compartido, en este caso, un archivo, para evitar
 * condiciones de carrera y corrupción de datos.
 */
public class Numeros {
    
    // Método principal. A través del array 'args' paso los argumentos desde la línea de comandos.
    public static void main(String[] args) {

        // Declaración de variables.
        // Entrada de datos por teclado en caso necesario.
        Scanner input = new Scanner(System.in);
        // Cantidad de números que se van a generar.
        int cantidadNumeros;
        // Nombre del fichero que se va a crear.
        String nombreFichero = "miFicheroDeNumeros.txt"; //Valor por defecto
        // Representa el archivo que se creará y en el que se escribirán los números.
        File archivo;

        // Compruebi si se están recibiendo argumentos en la línea de comandos.
        // Argumento1: cantidad de números aleatorios.
        if (args.length > 0) {
            cantidadNumeros = Integer.parseInt(args[0]);

            // Argumento2: nombre del fichero con extensión '.txt'
            if (args.length > 1) {
                nombreFichero = args[1];
            }
        } else {
            // Si no se pasan argumentos en línea de comandos, solicito los datos.
            System.out.print("Ingrese la cantidad de números aleatorios a generar: ");
            cantidadNumeros = input.nextInt();
            input.nextLine();
            System.out.print("Ingrese el nombre del fichero: ");
            nombreFichero = input.next();
            input.nextLine();
        }

        // Cierro el Scanner si ya no se necesita más, para liberar recursos.
        input.close();
        
        // Preparo el acceso al fichero.
        // Creo un objeto de tipo 'File' para representar el archivo.
        archivo = new File(nombreFichero);
        
        // Obtengo el ID del proceso que se está ejecutando.
        long pid = ProcessHandle.current().pid();
        
        // Creo una instancia de la clase Random para generar los números de forma aleatoria.
        Random random = new Random();
        
        // Para que cada número se escriba en una línea nueva.
        String lineSeparator = System.lineSeparator(); 
            
            // Abro el fichero para lectura y escritura, además para poder actualizar valores.
            // Lo hago con try-with-resources para evitar problemas con excepciones.
            try (RandomAccessFile raf = new RandomAccessFile(archivo, "rwd"); 
                // Obtengo el canal del archivo.  
                FileChannel channel = raf.getChannel()) {

                // Bucle que ejecuta tantas iteraciones como números se quieran generar.
                for (int i = 0; i < cantidadNumeros; i++) {
                    //******* INICIO SECCIÓN CRÍTICA *******//
                    // MECANISMO DE SINCRONIZACIÓN. 
                    // Locks (Candados): mecanismos que permiten el bloqueo de recursos, donde un proceso "toma" el lock antes de acceder a un recurso y lo "libera" después.
                    // Variable que almacena el bloqueo del archivo una vez que se adquiera.
                    FileLock lock = null; 
                    try {
                        // Intento obtener un bloqueo exclusivo de forma repetida en el archivo.
                        while (lock == null) {
                            // Sigo tratando de obtener el bloqueo del archivo.
                            try {
                                // Con el método trylock() trato de adquirir el bloqueo exclusivo
                                // del archivo si bloquear el hilo actual. Devolverá un objeto 'FileLock'
                                // si el bloqueo se adquiere con éxito, o 'null' si el bloqueo no 
                                // está disponible en ese momento.
                                lock = channel.tryLock();
                            // Esta excepción se lanza si la máquina virtual de Java ya ha adquirido un  bloqueo
                            // en ese archivo y no es un bloqueo compartido.Puede ocurrir si hay varios procesos
                            // en la misma JVM intentando bloquear el mismo archivo.
                            } catch (OverlappingFileLockException e) {
                                // Este bloque está destinado a hacer que el hilo actual se detenga temporalmente.
                                try {
                                    // Si el bloqueo no se puede obtener de inmediato (porque otro proceso lo tiene),
                                    // el proceso actual se pone en espera durante 50 milisegundos.
                                    // Esto introduce una pausa antes del próximo intento de adquirir el bloqueo,
                                    // reduciendo la frecuencia de intentos en el bucle 'while' y resultando más
                                    // eficiente de los recursos del sistema.
                                    Thread.sleep(50);
                                // Esta excepción se lanza si cualquier proceso ha interrumpido el proceso actual
                                // mientras estaba esperando.
                                } catch (InterruptedException ex) {
                                    Logger.getLogger(Numeros.class.getName()).log(Level.SEVERE, ex.getMessage(), ex);
                                }
                            }
                        }

                        // Mensaje de entrada a la sección crítica. Este mensaje se muestra también en consola.
                        System.out.println("Proceso " + pid + ": entra en la sección crítica.");

                        // Me muevo al final del archivo antes de escribir.
                        raf.seek(raf.length());
                        
                        // Genero los números de forma aleatoria.
                        int numAleatorio = random.nextInt(10000); // Números entre 0 y 9999.
                        
                        // Escribo los números en el archivo con su correspondiente proceso.
                        raf.writeBytes("Proceso " + pid + " escribe: " + numAleatorio + lineSeparator);
                        
                        // Verifico si el bloqueo no es nulo y si es válido.
                        if (lock != null && lock.isValid()) {
                            // Libero el proceso.
                            lock.release(); 
                            // NOTA: fundamental liberarlo una vez que se termina de usar el
                            // recurso compartido, para permitir que otros procesos puedan acceder a él.
                        }
                        
                        // Mensaje de salida de la sección crítica. Este mensaje se muestra también en consola.
                        System.out.println("Proceso " + pid + ": sale de la sección crítica.");
                        
                        // El proceso actual se pone en pausa 100 milisegundos, para simular tiempo de procesamiento,
                        // y reducir la posibilidad de que el sistema de archivos se sobrecargue por demasiadas operaciones
                        // de escritura en rápida sucesión.
                        Thread.sleep(100);
                        
                    // Esta excepción captura que un proceso esté esperando, durmiendo u ocupado de otra manera,
                    // y el proceso será interrumpido, ya sea antes o después de la actividad.
                    } catch ( InterruptedException e){
                        Logger.getLogger(Numeros.class.getName()).log(Level.SEVERE, e.getMessage(), e);
                    }
                    //******* FIN SECCIÓN CRÍTICA *******//
                } 
            // Esta excepción se lanza si hay problemas con el archivo creado.
            } catch (FileNotFoundException ex) {
            Logger.getLogger(Numeros.class.getName()).log(Level.SEVERE, ex.getMessage(), ex);
        // Esta excepción se lanza si existe algún problema con operaciones de E/S fallidas o interrumpidas.    
        } catch (IOException ex) {
            Logger.getLogger(Numeros.class.getName()).log(Level.SEVERE, ex.getMessage(), ex);
        }
    }
}

/*
<b>Otros métodos de sincronización que podrían haberse usado:</b>
1. Semáforos: variable o tipo de dato abstracto que se utiliza para controlar el acceso a un recurso común.
2. Monitores: estructuras de alto nivel que encapsulan variables, operaciones y semánticas de sincronización para proteger el acceso a datos.
	Un monitor asegura que un solo proceso puede ejecutar un pedazo de código a la vez.
*/