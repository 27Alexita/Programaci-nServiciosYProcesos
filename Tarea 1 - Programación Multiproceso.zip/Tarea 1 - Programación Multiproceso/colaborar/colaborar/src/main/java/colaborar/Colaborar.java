package colaborar;

import java.io.IOException; // Manejo de excepciones relacionadas con operaciones I/O.
import java.util.Arrays; // Para poder imprimir representaciones de arreglos como cadenas de texto.

/**
 * @author Sandra
 * Esta aplicación tiene como finalidad lanzar 10 instancias
 * de la aplicación 'numeros.jar'.
 * En este caso, escribirá 100 números por cada proceso.
 */
public class Colaborar {
    
    // Método principal. A través del array 'args' paso los argumentos desde la línea de comandos.
    public static void main(String[] args) {

        // Declaración de variables.
        // Cantidad de números que se van a generar.
        String numCantidad = "100";
        // Nombre del archivo en el que se escribirán los números.
        String nombreFichero = "miFicheroDeNumeros.txt";
        // Número de instancias que se lanzarán.
        int numInstancias = 10;
        
        // Si se proporcionan 2 argumentos, se utilizan en lugar de los predeterminados.
        if (args.length == 2) {
            numCantidad = args[0];
            nombreFichero = args[1];
        }

        try {
            // Creo el comando para ejecutar el programa 'numeros.jar'.
            String[] comando = {"java", "-jar", "numeros.jar", numCantidad, nombreFichero};
            
            // Bucle que lanza las 10 instancias
            for (int i = 0; i < numInstancias; i++) {
                System.out.println(" Lanzado el proceso: " + (i + 1));
                // Lanzo el proceso. Cada vez que se ejecute, lanza una nueva instancia de 'numeros.jar'.
                Process proceso = Runtime.getRuntime().exec(comando);
                System.out.println("Comando lanzado: " + Arrays.toString(comando));
            }
        } catch (IOException e) {
            // Captura cualquier excepción que pueda ocurrir al intentar ejecutar el comando
            //y muestra un mensaje de error.
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println("\nProceso de colaboración finalizado.\n" + "Se han lanzado 10 instancias de la aplicación números.");
    }
}

/*
<b>Observaciones:</b>
No hay ninguna gestión de la concurrencia tampoco en este archivo. Por tanto,
si 'numerosSinSeccionCritica.jar' escribe en el mismo archivo y se ejecuta
en paralelo, podría haber problemas como condiciones de carrera o corrupción de datos.

<b>- Condición de carrera:</b> 
Ocurre cuando dos o más procesos acceden a un recurso compartido (el archivo de texto
en este caso) y, al menos uno de los accesos es para escribir.
Si no se controla adecuadamente el acceso concurrente a ese recurso, los procesos pueden
"pisarse" entre sí sus resultados, llevando a un estado inconsistente o inesperado.

<b>- Corrupción de datos:</b>
Es el resultado de una condición de carrera que no ha sido manejada adecuadamente.
En el caso de un archivo, esto podría signficar que el archivo tiene partes de datos que 
no corresponden a los que debería haber escrito ninguno de los procesos involucrados.
*/