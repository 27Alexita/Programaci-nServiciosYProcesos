package numerossinseccioncritica;

import java.io.File; // Manejo de archivos.
import java.io.RandomAccessFile; // Manejo y manipulación de archivos de forma aleatoria.
import java.util.Random; // Generación de números aleatorios.
import java.util.Scanner; // Entrada de datos por teclado. 
import java.io.IOException; // Manejo de excepciones relacionadas con operaciones I/O.

/**
 * @author Sandra
 * Esta aplicación tiene como finalidad escribir 10 números 
 * aleatorios en un archivo, dentro de un mismo proceso.
 */
public class NumerosSinSeccionCritica {

    // Método principal. A través del array 'args' paso los argumentos desde la línea de comandos.
    public static void main(String[] args) {
        
        // Declaración de variables
        // Entrada de datos por teclado en caso necesario.
        Scanner input = new Scanner(System.in);
        // Cantidad de números que se van a generar.
        int cantidadNumeros;
        // Nombre del fichero que se va a crear.
        String nombreFichero = "miFicheroDeNumeros.txt"; //Valor por defecto
        // Representa el archivo que se creará y en el que se escribirán los números.
        File archivo;

        // Compruebo si se están recibiendo argumentos en la línea de comandos.
        // Argumento1: cantidad de números aleatorios.
        if (args.length > 0) {
            cantidadNumeros = Integer.parseInt(args[0]);

            // Argumento2: nombre del fichero con extensión '.txt'
            if (args.length > 1) {
                nombreFichero = args[1];
            }
        } else {
            // Si no se pasan argumentos en línea de comandos, solicito los datos.
            System.out.print("Ingrese la cantidad de números aleatorios a generar: ");
            cantidadNumeros = input.nextInt();
            input.nextLine();
            System.out.print("Ingrese el nombre del fichero: ");
            nombreFichero = input.next();
            input.nextLine();
        }

        // Cierro el Scanner si ya no se necesita más, para liberar recursos.
        input.close();
        
        // Preparo el acceso al fichero.
        // Creo un objeto de tipo 'File' para representar el archivo.
        archivo = new File(nombreFichero);
        
        // Obtengo el ID del proceso que se está ejecutando.
        long pid = ProcessHandle.current().pid();
        
        // Creo una instancia de la clase Random para generar los números de forma aleatoria.
        Random random = new Random();
        
        // Para que cada número se escriba en una línea nueva.
        String lineSeparator = System.lineSeparator(); 
            
            // Abro el fichero para lectura y escritura, además para poder actualizar valores.
            // Lo hago con try-with-resources para evitar problemas con excepciones.
            try (RandomAccessFile raf = new RandomAccessFile(archivo, "rwd"); ){
                // Bucle para escribir la cantidad de números solicitados.
                for (int i = 0; i < cantidadNumeros; i++) {
                // Me muevo al final del archivo antes de escribir.
                raf.seek(raf.length());
                // Genero los números de forma aleatoria.
                int numAleatorio = random.nextInt(10000); // Números entre 0 y 9999.
                // Escribo los números en el archivo con su correspondiente proceso.
                raf.writeBytes("Proceso " + pid + " escribe: " + numAleatorio + lineSeparator);
            }
        // Lanza la excepción si existe algún problema con operaciones de E/S fallidas o interrumpidas.
        } catch (IOException ex) {
            System.out.println("Se ha producido el siguiente ERROR: " + ex.getMessage());
        }
    }
}

/*
<b>Observaciones:</b>
Este programa no contiene una "sección crítica" (término utilizado en programación 
concurrente, lo que significa que, si se ejecuta simultáneamente por varios procesos,
se podrían dar condiciones de carrera que causen que las escrituras en el archivo se
sobrescriban o intercalen de maneras inesperadas, como vamos a comprobar al ejecutar
la aplicación colaboración.
*/

