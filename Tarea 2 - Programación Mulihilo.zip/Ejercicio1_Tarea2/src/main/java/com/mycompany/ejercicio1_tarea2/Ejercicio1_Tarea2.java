package com.mycompany.ejercicio1_tarea2;

import java.util.concurrent.Semaphore;

/**
 *  Programa que crea una serie de hilos que escriben números aleatorios
 * en el archivo "datos.txt", utilizando un semáforo para sincronizar el 
 * acceso y evitar que los hilos escriban en el archivo al mismo tiempo.
 * @author Sandra
 */
public class Ejercicio1_Tarea2 {

    public static void main(String[] args) {
        
        // Creo el semáforo. 
        // Únicamente un hilo podrá abrir y escribir a la vez. (Permits 1)
        Semaphore semaphore = new Semaphore(1);
        
        // Creo un array de hilos de tamaño 10.
        HiloEscritor[] hilo = new HiloEscritor[10];
        
        // Para cada índice del array: 
        for (int i = 0; i < 10; i++){
            hilo[i] = new HiloEscritor("Hilo " + (i + 1), semaphore); // Se instancia un nuevo 'HiloEscritor' con dicho ID y semáforo.
            hilo[i].start(); // Se inicia el hilo, que a su vez llamará internamente al método 'run()'.
        }
        
        // Para cada hilo el método 'join()' espera a que termine su ejecución.
        // Esto asegura que el programa principal no termine antes de que los hilos
        // hayan completado su trabajo.
        for(int i = 0; i < 10; i++){
            try{
                hilo[i].join();
            } catch (InterruptedException e){
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
