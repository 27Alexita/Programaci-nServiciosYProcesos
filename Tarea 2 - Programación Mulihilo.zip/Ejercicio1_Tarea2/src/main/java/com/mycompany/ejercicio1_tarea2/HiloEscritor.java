package com.mycompany.ejercicio1_tarea2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.concurrent.Semaphore;


/**
 * Clase que implementa el hilo escritor. Hereda de la clase Thread, 
 * lo que le permite ser ejecutada en un hilo separado de ejecución
 * en Java.
 * @author Sandra
 */
public class HiloEscritor extends Thread { 
    
    // Instancia del semáforo, para controlar el acceso al archivo.
    private Semaphore semaforo;
    
    // Constructor al que le paso por parámetro el semáforo y el ID del hilo.
    public HiloEscritor (String hiloId, Semaphore semaphore){
        super(hiloId);
        this.semaforo = semaphore;
    }
    
    @Override
    // Método que se ejecutará cuando el hilo comience.
    public void run() {
        
        try{
            // Adquiero el semáforo antes de realizar la escritura en el archivo, 
            // para asegurar que un solo hilo puede escribir en él.
            semaforo.acquire();
            System.out.println(getName() + " bloquea el semáforo para escribir en el archivo.");
            
            // Creación del archivo 'datos.txt' con try-with-resources.
            try(PrintWriter writer = new PrintWriter (new FileWriter ("datos.txt",true))){
                writer.println(getName() + ": " + new Random().nextInt(100)); 
                // Se escribe un número aleatorio en el archivo en modo 'añadir (append = true)'.
            } catch (IOException e){
                System.out.println("Error: " + e.getMessage());
            }
            
            // Se libera el semáforo después de que la escritura se ha completado,
            // para permitir que otro hilo tenga acceso al archivo.
            System.out.println(getName() + " libera el semáforo.");
            semaforo.release();
            
        } catch (InterruptedException e){
            System.out.println("Error: " + e.getMessage());
        }
    } 
}

/*
 El bloqueo y la liberación del semáforo se manejan en el método 'run()', 
que es el método que se ejecuta en un hilo separado cuando se llama al método
'start()' en una instancia de 'Thread' o de una subclase de 'Thread'.

BLOQUEO DEL SEMÁFORO: semaforo.acquire();

Este método intenta obtener un permiso del semáforo.
- Si el permiso está disponible (es decir, si el contador de permisos del semáforo es
mayor que 0), entonces se reduce el número de permisos disponibles y el hilo 
continua ejecutando.
- Si no hay permisos disponibles (contador de permisos = 0), entonces el hilo actual
se bloquea y espera hasta que otro hilo libere un permiso.

LIBERACIÓN DEL SEMÁFORO: semaforo.release();

Este método incrementa el número de permisos disponibles del semáforo.
- Si hay otros hilos esperando, uno de ellos será seleccionado por el planificador
del sistema operativo para adquirir el permiso que acaba de ser liberado y continuar
su ejecución.

COMPORTAMIENTO DE LOS HILOS:

Cuando un hilo llama a 'semaforo.acquire()' y no hay permisos disponibles, porque
otro hilo ya ha adquirido el semáforo, el hilo que está intentando adquirir se bloquea
y permanece en espera. 
No sigue ejecutando el código posterior a 'acquire()' y no "vuelve a intentarlo más tarde"
por sí solo. Se queda en espera hasta que el permiso se libera con un 'release()'
de algún otro hilo, y solo en ese momento el hilo bloqueado puede continuar ejecutando
el código después del 'acquire()'. Esto asegura la exclusión mutua, ya que solo un 
hilo puede ejecutar el código entre 'acquire()' y 'release()' en un momento dado.

*/