package com.mycompany.ejercicio2_tarea2;

import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 * Clase Persona. Representa a una persona que intenta comprar un billete de
 * metro. Es una simulación donde cada persona es un hilo que compite por
 * acceder a una máquina de billetes compartida. Hereda de Thread, lo que le
 * permite ser ejecutada en un hilo separado de ejecución en Java.
 *
 * @author Sandra
 */
public class Persona extends Thread {

    // Instancia de random para generar tiempos de espera aleatorios.
    private static Random random = new Random(); // Static para que sea común a todas las instancias de 'Persona'.
    // Semáforo que regula el acceso a la máquina de billetes.
    private static Semaphore maquina; // Static porque se comparte entre todas las instancias de 'Persona'.

    // Constructor que asignará el ID de la persona y la referencia al semáforo compartido.
    public Persona(String nombre, Semaphore maquina) {
        super(nombre);
        Persona.maquina = maquina;
    }

    @Override 
    // Método que se ejecuta cuando el hilo comienza.
    public void run(){
        System.out.println("Ha llegado la " + getName() + "."); // Muestra la persona que llega.
        try{
            maquina.acquire(); // Intenta adquirir el permiso del semáforo.
            // - Si está disponible: la persona (hilo) procede a comprar.
            // - Si no está disponible: la persona (hilo) se bloquea y espera su turno.
        } catch (InterruptedException e){
            System.out.println("Error. " + getName() + " no ha podido comprar su billete.");
        }
        System.out.println(getName() + " inicia la compra de su billete."); // Mensaje en consola para comprobar el funcionamiento.
        
        try{
            sleep((random.nextInt(3) + 1) * 1000); // Simula la compra durante 1 - 3 segundos.
            // Se duerme el  hilo para simular que la persona tarda ese tiempo en comprar el billete.
        } catch (InterruptedException e){
            System.out.println("Error. " + getName() + " ha sido interrumpida mientras compraba el billete.");
        }
        System.out.println(getName() + " ha terminado de comprar el billete."); // Mensaje en consola para comprobar el funcionamiento.
        
        // Se libera el permiso del semáforo, permitiendo que otra persona (hilo) proceda con su compra.
        maquina.release();    
    }
}

/*
 En esta clase se maneja la lógica para bloquear y liberar el semáforo para simular
la compra de un billete en una máquina, dentro del método 'run()'.

BLOQUEO DEL SEMÁFORO: maquina.acquire();

Este método intenta obtener un permiso del semáforo máquina.
- Si está disponible, es decir, si el contador de permisos del semáforo es mayor que 0, 
entonces el semáforo se concede y el contador se decrementa.
- Si no hay permisos disponibles, el hilo que invocó 'acquire()' se bloqueará y esperará
hasta que otro hilo libere un permiso.

LIBERACIÓN DEL SEMÁFORO: maquina.release();

Este método también está dentro de 'run()', en el bloque 'finally', lo que asegura que se
ejecuta incluso si se lanza una excepción. Este método incrementa el contador de permisos
del semáforo 'maquina', potencialmente desbloqueando un hilo que estaba esperando para
adquirir el semáforo.

COMPORTAMIENTO DE LOS HILOS CON RESPECTO AL SEMÁFORO:

- Cuando un hilo (una instancia de 'Persona') llama a 'maquina.acquires' y no hay permisos
disponibles porque otro hilo ya ha adquirido el semáforo, el hilo que intenta el 'acquire()'
se bloquea y queda en espera.

- Los hilos bloqueados no ejecutan código adicional; se quedan esperando hasta que el permiso
sea liberado.

- No hay un "vuelven a intentarlo más tarde" implícito. El hilo permanece inactivo en el punto de
'acquire()' hasta que se liberea un permiso del semáforo.

- Una vez que un permiso se libera, uno de los hilos en espera (no necesariamente el que
lleva más tiempo esperando, ya que esto puede depender de la política del planificador de hilos
del SO) adquiere el semáforo y continúa su ejecución.

El uso del semáforo de esta manera asegura que, aunque hay varios hilos intentando acceder
a la misma máquina (recurso compartido), sólo uno puede "usar" la máquina de un momento
dado, imitando la exclusión mutua.
 */

 /*
LAS PERSONAS EN VEZ DE ESPERAR, MARCHAN A DAR UN PASEO DURANTE 5 SEGUNDOS:

En este caso, los cambios se realizan en la lógica del hilo de la clase 'Persona'.
Este cambio refleja una situación donde los hilos NO SE BLOQUEAN inmediatamente
si el recurso no está disponible, sino que REALIZAN OTRA ACCIÓN ("dar un paseo"
en este caso) y luego vuelven a intentarlo. Por tanto:

- En lugar de llamar a 'maquina.acquire()', que bloquea el hilo hasta que un permiso
está disponible, utilizo un bucle que intenta adquirir un permiso con 'maquina.tryAcquire()'.
Si no tiene éxito porque el semáforo está ocupado, el hilo se dormirá durante 5 segundos
para simular el paseo.

@Override
public void run() { 
    System.out.println("Ha llegado la " + getName() + ".);
    boolean haComprado = false; // Variable que indica si la persona (hilo) ha comprado su billete.

    while (!haComprado) { // Mientras la persona (hilo) no haya comprado su billete.
        try{
            if (maquina.tryAcquire()) { // Intenta adquirir un permiso del semáforo
                try {
                    System.out.println(getName() + " inicia la compra del billete.");
                    sleep((random.nextInt(3) + 1) * 1000); // Simula la compra del billete entre 1 y 3 segundos.
                    System.out.println(getName() + " ha terminado de comprar el billete.");
                    haComprado = true;
                } catch (InterruptedException e) {
                    System.out.println("Error. " + getName() + " ha sido interrumpida.");
                } finally {
                    // Libera el permiso del semáforo.
                    maquina.release();
                }
            } else {
                // Si la máquina está ocupada, la persona se va a dar un paseo.
                try {
                    System.out.println(getName() + " va a darse un paseo mientras la máquina está ocupada".);
                    // El paseo se dará durante 5 segundos.
                    sleep(5000);
                } catch (InterruptedException e) {
                    System.out.println("Error. " + getName() + " ha sido interrumpida durante su paseo.);
                }
            }
        } catch (InterruptedException e){
            System.out.println("Erro. " + getName() + " ha sido interrumpida mientras esperaba o paseaba".);
        }
    }
}
 */
