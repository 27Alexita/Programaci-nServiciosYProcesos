package com.mycompany.ejercicio2_tarea2;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase principal que simula la compra de billetes de metro de 
 * 20 personas, utilizando un único semáforo para controlar el 
 * acceso a la máquina de billetes.
 * @author Sandra
 */
public class Ejercicio2_Tarea2 {
    
    // Constante que define el número de personas que intentarán comprar un billete.
    private static final int NUM_PERSONAS = 20;

    public static void main(String[] args) {
        
        // Instancia del semáforo con un permiso disponible, por tanto, solo una persona puede comprar el billete.
        Semaphore maquina = new Semaphore(1);
        // Array de 'Persona' de tamaño 'NUM_PERSONAS' para almacenar las referencias a los hilos que representan las personas.
        Persona[] personas = new Persona[NUM_PERSONAS];
        // Registro del tiempo de inicio actual en milisegundos para calcular la duración total de la simulación al final.
        long startTime = System.currentTimeMillis();
        
        // Bucle para crear y lanzar hilos. Inicia cada hilo y almacena la referencia en el array.
        for (int i = 0; i < NUM_PERSONAS; i++){
            personas[i] = new Persona ("Persona " + (i + 1), maquina); // Instancia de 'Persona' con su ID y el semáforo.
            personas[i].start(); // Se inicia el hilo.
            try {
                Thread.sleep(1000); // El hilo principal espera 5 segundos antes de lanzar el siguiente hilo.
                // Esto simularía la llegada escalonada de las personas a la máquina de billetes.
            } catch (InterruptedException ex) {
                Logger.getLogger(Ejercicio2_Tarea2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        // Bucle para esperar a que todos los hilos terminen. Se itera sobre el array 'personas':
        for (Persona persona : personas){
            try {  
                // Espera a que la persona termine de comprar su billete.
                // Imprescindible este método para que terminen todos los hilos y calcular el tiempo total.
                persona.join(); 
            } catch (InterruptedException ex) {
                Logger.getLogger(Ejercicio2_Tarea2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        // Ahora que todos los hilos han terminado, cálculo el tiempo total:
        long totalTime = (System.currentTimeMillis() - startTime)/1000;
        System.out.println("Todas las personas han comprado su billete en " + totalTime + "s.");
    }
}

/*
Para esperar a que todos los hilos terminen, se necesita mantener las referencias
a dichos hilos ('Personas') y llamar a 'join()' en cada uno de ellos.
Esto asegura que el hilo principal ('main') espera a que todos los hilos de 'Persona'
hayan terminado antes de calcular el tiempo total. Para ello se declara un array 'personas'
que almacena cada hilo 'Persona'.

El método 'join()' es crucial cuando se necesita sincronizar el final de los hilos
con alguna otra operación, como calcular el tiempo total que se tarda en ejecutar
todos los hilos, o por ejemplo, cuando es necesario asegurarse de que ciertos recursos
no se liberan o modifican hasta que todos los hilos hayan completado su trabajo.
*/

/*
 2 MÁQUINAS DE BILLETES QUE PUEDEN ATENDER A 2 PERSONAS A LA VEZ:

            Semaphore maquina = new Semaphore(2);

Debo aumentar el número de permisos del semáforo, para permitir que dos hilos
puedan ejecutar su sección crítica (compra del billete) al mismo tiempo,
lo que reflejaría la disponibilidad de dos máquinas de billetes.

Con dos permisos en el semáforo la simulación se completa en menos tiempo lógicamente. 
Esto dependerá de cómo los hilos se programen y se ejecuten
en el SO, pero en general, debería aumentar la eficiencia de la simulación.
*/

